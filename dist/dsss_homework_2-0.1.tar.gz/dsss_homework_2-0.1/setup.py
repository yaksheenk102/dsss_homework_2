from setuptools import setup, find_packages
setup(
    name='dsss_homework_2',
    version='0.1',
    packages=['math_quiz'],
    install_requires=[
        # your dependencies here
    ]
)